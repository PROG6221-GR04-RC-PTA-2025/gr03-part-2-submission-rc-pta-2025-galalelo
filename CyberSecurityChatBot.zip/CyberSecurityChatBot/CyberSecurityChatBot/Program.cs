﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Linq;
using System.Text.RegularExpressions;

class CyberSecurityChatBot
{
    private static Dictionary<string, List<string>> responses;
    private static Dictionary<string, int> topicCounters = new Dictionary<string, int>();
    private static UserProfile currentUser;
    private static List<string> conversationHistory = new List<string>();

    class UserProfile
    {
        public string Name { get; set; }
        public DateTime FirstInteraction { get; set; }
        public DateTime LastInteraction { get; set; }
        public Dictionary<string, int> TopicInterests { get; set; } = new Dictionary<string, int>();
        public string UserMood { get; set; } = "neutral";
    }

    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        // Play welcome sound
        Welcome("welcome audio.wav");

        ShowWelcomeArt();

        InitializeUser();
        InitializeResponses();

        string welcomeMessage = $"\nHello, {currentUser.Name}! I am your Cyber Security Assistant. " +
                               $"Last time we spoke was {(currentUser.LastInteraction == DateTime.MinValue ? "this is our first chat!" : "on " + currentUser.LastInteraction.ToString("g"))}.\n" +
                               "Ask me about password safety, phishing, safe browsing, or other security topics.\n";
        Console.WriteLine(welcomeMessage);

        MainConversationLoop();

        // Save user data when exiting
        currentUser.LastInteraction = DateTime.Now;
        // In a real app, you would save to a file or database here
    }

    static void ShowWelcomeArt()
    {
        Console.WriteLine(@"__        __   _                            _                        
\ \      / /__| | ___ ___  _ __ ___   ___  | |_ ___                  
 \ \ /\ / / _ \ |/ __/ _ \| '_ ` _ \ / _ \ | __/ _ \                 
  \ V  V /  __/ | (_| (_) | | | | | |  __/ | || (_) |                
  _\_/\_/ \___|_|\___\___/|_| |_|_|_|\___|  \__\___/     _ _         
 / ___|   _| |__   ___ _ __  / ___|  ___  ___ _   _ _ __(_) |_ _   _ 
| |  | | | | '_ \ / _ \ '__| \___ \ / _ \/ __| | | | '__| | __| | | |
| |__| |_| | |_) |  __/ |     ___) |  __/ (__| |_| | |  | | |_| |_| |
 \____\__, |_.__/ \___|_|    |____/ \___|\___|\__,_|_|  |_|\__|\__, |
 ____ |___/  _                                                 |___/ 
| __ )  ___ | |_                                                     
|  _ \ / _ \| __|                                                    
| |_) | (_) | |_                                                     
|____/ \___/ \__|                                                    ");
    }

    static void InitializeUser()
    {
        currentUser = new UserProfile();

        Console.Write("\nPlease enter your name: ");
        string userName = Console.ReadLine().Trim();

        while (string.IsNullOrEmpty(userName))
        {
            Console.Write("Name cannot be empty. Please enter your name: ");
            userName = Console.ReadLine().Trim();
        }

        currentUser.Name = userName;
        currentUser.FirstInteraction = DateTime.Now;
        currentUser.LastInteraction = DateTime.Now; // Would load from storage in real app
    }

    static void InitializeResponses()
    {
        responses = new Dictionary<string, List<string>>()
        {
            {
                "password",
                new List<string> {
                    "Use a strong password with a mix of letters, numbers, and symbols. Avoid using personal information. Consider using a password manager.",
                    "For password safety, make sure each account has a unique password. Length is more important than complexity - aim for at least 12 characters.",
                    "Password tip: Use passphrases instead of passwords. For example, 'PurpleTiger$JumpsHigh!' is both strong and memorable."
                }
            },
            {
                "phishing",
                new List<string> {
                    "Be cautious of emails or messages asking for personal details. Verify links before clicking. Look for spelling errors and suspicious sender addresses.",
                    "Phishing attacks often create urgency ('Your account will be closed!'). Always verify through official channels before responding.",
                    "Watch for phishing scams where criminals impersonate trusted organizations. Never give credentials via email or text."
                }
            },
            {
                "browsing",
                new List<string> {
                    "Use HTTPS websites, avoid downloading files from untrusted sources, and keep your browser updated. Use browser security extensions.",
                    "For safe browsing, check for the padlock icon in your address bar and be cautious with public Wi-Fi networks.",
                    "Browser safety tip: Clear cookies regularly and use private browsing mode when accessing sensitive information on shared computers."
                }
            },
            {
                "authentication",
                new List<string> {
                    "Enable multi-factor authentication (MFA) whenever possible to add an extra layer of security beyond just your password.",
                    "For important accounts, use authentication apps rather than SMS for two-factor authentication as they're more secure.",
                    "Biometric authentication (fingerprint, face ID) combined with a password provides excellent security when available."
                }
            },
            {
                "vpn",
                new List<string> {
                    "A Virtual Private Network (VPN) encrypts your internet connection, keeping your online activity private and secure, especially on public Wi-Fi.",
                    "VPNs hide your IP address and location. Choose a reputable provider that doesn't keep logs of your activity.",
                    "Using a VPN? Remember it protects your data in transit but doesn't make you anonymous from all tracking."
                }
            },
            {
                "malware",
                new List<string> {
                    "Use reliable antivirus software and be cautious of email attachments or downloads from unknown sources. Regular system scans are recommended.",
                    "Malware can come from malicious ads, fake software updates, or pirated content. Keep your software updated from official sources.",
                    "Ransomware is particularly dangerous. Always maintain backups of important files in a separate location."
                }
            }
        };
    }

    static void MainConversationLoop()
    {
        while (true)
        {
            Console.Write("\nYou: ");
            string userInput = Console.ReadLine().Trim();

            if (string.IsNullOrEmpty(userInput))
            {
                Console.WriteLine("ChatBot: Please enter a valid query.");
                continue;
            }

            // Add to conversation history
            conversationHistory.Add(userInput);

            // Detect sentiment
            currentUser.UserMood = DetectSentiment(userInput);

            if (userInput.ToLower() == "exit" || userInput.ToLower() == "quit")
            {
                string goodbyeMessage = GetPersonalizedGoodbye();
                Console.WriteLine($"ChatBot: {goodbyeMessage}");
                break;
            }
            else if (userInput.ToLower().Contains("remember") || userInput.ToLower().Contains("recall"))
            {
                HandleMemoryRequest(userInput);
            }
            else if (userInput.ToLower() == "history")
            {
                ShowConversationHistory();
            }
            else if (userInput.ToLower() == "topics")
            {
                ShowFavoriteTopics();
            }
            else
            {
                string bestMatch = FindBestMatch(userInput.ToLower(), responses.Keys);

                if (bestMatch != null)
                {
                    // Update user interests
                    if (!currentUser.TopicInterests.ContainsKey(bestMatch))
                    {
                        currentUser.TopicInterests[bestMatch] = 0;
                    }
                    currentUser.TopicInterests[bestMatch]++;

                    // Get response based on mood and interest level
                    string response = GetContextualResponse(bestMatch, userInput);
                    Console.WriteLine($"ChatBot: {response}");
                }
                else
                {
                    RespondToUnknownQuery();
                }
            }
        }
    }

    static string DetectSentiment(string input)
    {
        input = input.ToLower();

        // Positive indicators
        var positiveWords = new[] { "thanks", "thank you", "awesome", "great", "cool", "helpful", "appreciate" };
        if (positiveWords.Any(word => input.Contains(word)))
            return "positive";

        // Negative indicators
        var negativeWords = new[] { "stupid", "useless", "dumb", "hate", "sucks", "terrible", "awful" };
        if (negativeWords.Any(word => input.Contains(word)))
            return "negative";

        // Question pattern
        if (input.Contains("?") || input.StartsWith("how") || input.StartsWith("what") || input.StartsWith("why"))
            return "curious";

        return "neutral";
    }

    static string GetContextualResponse(string topic, string userInput)
    {
        // Track topic count
        if (!topicCounters.ContainsKey(topic))
        {
            topicCounters[topic] = 0;
        }
        topicCounters[topic]++;

        // Get all possible responses for this topic
        List<string> possibleResponses = responses[topic];

        // Select response based on counter (cycles through responses)
        string baseResponse = possibleResponses[topicCounters[topic] % possibleResponses.Count];

        // Customize based on sentiment
        switch (currentUser.UserMood)
        {
            case "positive":
                return baseResponse + " I'm glad you're interested in security!";
            case "negative":
                return "I'm sorry you're feeling frustrated. " + baseResponse + " Let me know if you need clarification.";
            case "curious":
                return "That's a great question! " + baseResponse;
            default:
                return baseResponse;
        }
    }

    static void HandleMemoryRequest(string input)
    {
        if (input.ToLower().Contains("name"))
        {
            Console.WriteLine($"ChatBot: Of course, {currentUser.Name}! I remember you. We first met on {currentUser.FirstInteraction:d}.");
        }
        else if (input.ToLower().Contains("talk") || input.ToLower().Contains("discuss"))
        {
            if (currentUser.TopicInterests.Any())
            {
                var favoriteTopic = currentUser.TopicInterests.OrderByDescending(x => x.Value).First();
                Console.WriteLine($"ChatBot: We've discussed {favoriteTopic.Key} {favoriteTopic.Value} times. Would you like to know more about it?");
            }
            else
            {
                Console.WriteLine("ChatBot: We haven't discussed many topics yet. Ask me about cybersecurity!");
            }
        }
        else
        {
            Console.WriteLine($"ChatBot: I remember you, {currentUser.Name}! We've been talking since {currentUser.FirstInteraction:t}. " +
                              $"You seem interested in security topics.");
        }
    }

    static void ShowConversationHistory()
    {
        Console.WriteLine("\nChatBot: Here's our conversation history:");
        for (int i = 0; i < conversationHistory.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {conversationHistory[i]}");
        }
    }

    static void ShowFavoriteTopics()
    {
        if (currentUser.TopicInterests.Any())
        {
            Console.WriteLine("\nChatBot: Your top interests in our conversation:");
            var orderedTopics = currentUser.TopicInterests.OrderByDescending(x => x.Value);
            foreach (var topic in orderedTopics)
            {
                Console.WriteLine($"- {topic.Key}: {topic.Value} times");
            }
        }
        else
        {
            Console.WriteLine("ChatBot: We haven't discussed enough topics yet to determine your interests.");
        }
    }

    static string GetPersonalizedGoodbye()
    {
        string[] goodbyes = {
            $"Stay safe online, {currentUser.Name}! Remember to use strong passwords!",
            $"Goodbye {currentUser.Name}! It was great discussing cybersecurity with you.",
            $"See you later {currentUser.Name}! Don't forget to enable 2FA on your important accounts!",
            $"Until next time {currentUser.Name}! Keep your software updated for better security."
        };

        Random rand = new Random();
        return goodbyes[rand.Next(goodbyes.Length)];
    }

    static void RespondToUnknownQuery()
    {
        string[] unknownResponses = {
            "I'm not sure about that. Try asking about password safety, phishing, or other cybersecurity topics.",
            "That's not something I'm programmed to help with. I specialize in cybersecurity topics.",
            "I don't have information on that. Maybe ask about internet safety or malware protection?",
            "My expertise is cybersecurity. Could you ask about something like VPNs or secure passwords?"
        };

        Random rand = new Random();
        Console.WriteLine($"ChatBot: {unknownResponses[rand.Next(unknownResponses.Length)]}");
    }

    static string FindBestMatch(string userInput, IEnumerable<string> keywords)
    {
        foreach (var keyword in keywords)
        {
            if (userInput.Contains(keyword))
            {
                return keyword;
            }
        }

        // Flexible matching
        if (userInput.Contains("password") || userInput.Contains("secure password") || userInput.Contains("strong password"))
            return "password";
        if (userInput.Contains("phish") || userInput.Contains("scam email") || userInput.Contains("fake email"))
            return "phishing";
        if (userInput.Contains("browsing") || userInput.Contains("internet safety") || userInput.Contains("web security"))
            return "browsing";
        if (userInput.Contains("mfa") || userInput.Contains("two-factor") || userInput.Contains("2fa") || userInput.Contains("multi-factor"))
            return "authentication";
        if (userInput.Contains("public wifi") || userInput.Contains("free wifi") || userInput.Contains("hotspot"))
            return "wifi";
        if (userInput.Contains("virus") || userInput.Contains("antivirus") || userInput.Contains("trojan") || userInput.Contains("ransomware"))
            return "malware";

        return null;
    }

    static void Welcome(string filepath)
    {
        try
        {
            SoundPlayer player = new SoundPlayer(filepath);
            player.Play();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error playing sound: {ex.Message}");
        }
    }
}